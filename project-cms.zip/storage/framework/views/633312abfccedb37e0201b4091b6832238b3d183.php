  <?php $__env->startSection('content'); ?>

   
     

    <div class="d-flex flex-column align-items-center mb-5">
       <div class="align-self-end">
        <a href=" <?php echo e(route('posts.create')); ?> " class="btn btn-primary mb-3"> Create Post</a>
        </div>
        
          <?php if($posts->count() > 0): ?>

            <div class="card" style="width: 100%">
              <div class="card-header">
                  Posts List
              </div>
            <div class="mb-0">
                <table class="table table-bordered mb-0">
              <thead>
                <tr>
                <th scope="col">Image</th>
                <th scope="col">title</th>
                <th scope="col">Category</th>
                <th scope="col"></th>

                </tr>
             </thead>
              <tbody >
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="" style="width: 50px"></td>
                <td>
                  <?php if(strlen($post->title) > 30): ?>
                    <?php echo e(substr($post->title,0,30)); ?>..
                  <?php else: ?>
                    <?php echo e($post->title); ?>

                  <?php endif; ?>
                </td>
                <td><a href="<?php echo e(route('categories.edit',$post->category->id)); ?>"><?php echo e($post->category->name); ?></a></td>
                <td class="text-center">
                 <?php if(!$post->trashed()): ?>
                    <a href="<?php echo e(route('posts.edit' , $post->id)); ?>" class="btn btn-sm btn-info ml-2 mr-2">Edit</a>
                 <?php else: ?>
                    <a href="<?php echo e(route('trashed-posts-store.index' , $post->id)); ?>" class="btn btn-sm btn-info ml-2 mr-2">Restore</a>
                 <?php endif; ?>
                 <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="submit" class="btn btn-sm btn-danger d-inline" >
                      <?php echo e($post->trashed() ? 'Delete' : 'Trashed'); ?>

                   </button>
                 </form>
                </td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>          
              </table>
          </div>
            </div>
           <div class="mt-3">
              <?php echo e($posts->links('pagination::simple-tailwind')); ?>

           </div>
          <?php else: ?>
              <h2>No Post Yet</h2>
          <?php endif; ?>

    </div>

   <?php $__env->stopSection(); ?>

   





<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/posts/index.blade.php ENDPATH**/ ?>