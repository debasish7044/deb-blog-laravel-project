   <?php $__env->startSection('content'); ?>

  <div class="d-flex flex-column align-items-center" >
  <div class="card" style="width:100%">


    <div class="card-header">
    <?php echo e(isset($category) ? 'Update Category' : 'Create Creategory'); ?>

    </div>
    <form action="<?php echo e(isset($category) ? route('categories.update',$category->id) : route('categories.store')); ?>" method="POST" class="p-3">
        <!-- Name input -->
        <?php if(isset($category)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <?php echo csrf_field(); ?>


        <div class="form-outline">
        <label class="form-label" for="form7Example1">Name</label>

        <input type="text" name="name" class="form-control p-2" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(isset($category) ? $category->name : ' '); ?>" />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="btn btn-primary mt-3"><?php echo e(isset($category) ? 'Save' : 'Add Category'); ?></button>
        </div>
    </form>

    </div>

   </div>
   <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/categories/create.blade.php ENDPATH**/ ?>