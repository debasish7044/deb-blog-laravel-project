   <?php $__env->startSection('content'); ?>

    <div class="d-flex flex-column align-items-center mb-4">

    <div class="card" >
    <div class="card-header">
        <?php echo e(isset($post) ? 'Update Post' : 'Create Post'); ?>

    </div>

  <form action="<?php echo e(isset($post) ? route('posts.update',$post->id) : route('posts.store')); ?>" method="POST" class="p-3"  enctype="multipart/form-data">

    <!-- 2 column grid layout with text inputs for the first and last names -->
   <?php if(isset($post)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <?php echo csrf_field(); ?>


  <div class="row mb-4">
    <div class="col">
      <div class="form-outline">
      <label class="form-label" for="title">Title</label>
        <input type="text" id="title" name="title" class="form-control mb-4 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($post) ? $post->title : old('title')); ?>"/>
         <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>


  
  <div class="form-outline mb-4">
    <label class="form-label" for="description">Description</label>
    <textarea class="form-control  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" id="description" rows="4"><?php echo e(isset($post) ? $post->description : old('description')); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
         <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>


 <div class="form-outline mb-4">
 <label class="form-label" for="content">Content</label>

     
      <textarea class="form-control" id="summary-ckeditor" name="content"><?php echo e(isset($post) ? $post->content : old('content')); ?></textarea>
      <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
         <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>


   <div class="form-outline">
      <label class="form-label" for="publish_at">Publish At</label>
        <input type="text" id="publish_at" name="publish_at" class="form-control mb-4 <?php $__errorArgs = ['publish_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($post) ? $post->publish_at : old('publish_at')); ?>"/>
         <small class="form-text text-muted">If you want publish the post then put current time.</small>

        <?php $__errorArgs = ['publish_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if(isset($post)): ?>
       <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->name); ?>" style="width: 20%">
    <?php endif; ?>

    <div class="form-group">
        <label class="mb-2 d-block" for="image">Choose Image</label>
        <input type="file" name="image" id="image" value=<?php echo e(old('image')); ?> class=" from-control p-2 mb-4 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
         <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger p-2 mt-2"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>
   </div>
   

    <div class="form-group col-md-4 mb-4">
      <label class="mb-2" for="category">Choose Category</label>
      <select id="category" name="category" class="form-control ">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
            <?php if(isset($post)): ?>

            <?php if($category->id == $post->category_id): ?>
               selected
            <?php endif; ?>
            <?php endif; ?>
            value="<?php echo e($category->id); ?>"
            ><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>


    <?php if($tags->count() > 0): ?>
    <label class="mb-2" for="tags">Choose Tags</label>
    <select class=" mb-3 form-outline tags-selector" style="width: 100%" name="tags[]" multiple>

        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tag->id); ?>"
                <?php if(isset($post)): ?>
                    <?php if($post->hasTag($tag->id)): ?>
                        selected
                    <?php endif; ?>
                <?php endif; ?>
                ><?php echo e($tag->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   <?php endif; ?>


  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block mb-2 mt-5 d-block">
      <?php if(isset($post)): ?>
        Save
      <?php else: ?>
       Add Post
      <?php endif; ?>
  </button>
  </form>
  </div>

   </div>
   <?php $__env->stopSection(); ?>

   

    <?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
   
    <?php $__env->stopSection(); ?>

     <?php $__env->startSection('script'); ?>
      
       <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
        <script>
            $('.tags-selector').select2({
            theme: 'bootstrap5',
        });
        </script>
        
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script>
            flatpickr("#publish_at",{
              enableTime: true,
              enableSeconds: true
            });
            $(document).ready(function() {
                $('.tags-selector').select2();
            });
            
        </script>
  
       <script>
      window.onload = function() {
        CKEDITOR.replace( 'summary-ckeditor', {
          filebrowserUploadUrl: '<?php echo e(route('upload',['_token' => csrf_token() ])); ?>',
          filebrowserUploadMethod: 'form'
        });
	};
</script>
        
    <?php $__env->stopSection(); ?>
    
     
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/posts/create.blade.php ENDPATH**/ ?>