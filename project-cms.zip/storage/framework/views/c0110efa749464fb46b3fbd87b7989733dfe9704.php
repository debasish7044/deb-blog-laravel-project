   <?php $__env->startSection('content'); ?>

    <div class="card" style="width: 90%">
          <div class="card-header">
             <?php echo e(__('Dashboard')); ?>

          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">You are logged in !!</li>
       </ul>
   </div>
   <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/dashboard.blade.php ENDPATH**/ ?>