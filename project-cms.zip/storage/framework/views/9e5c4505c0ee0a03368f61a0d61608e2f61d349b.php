<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
      <?php echo view('laravel-trix::trixassets')->render(); ?>
      <?php echo $__env->yieldContent('css'); ?>
      <style>
         a.btn.btn-info.ml-2.mr-2 {
         color: #fff;
        }
      </style>
     
      <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>


   <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

   <div class="container mt-5">
    <?php if(session('success')): ?>
    <div class="alert alert-success successMessage" >
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="alert alert-danger errorMessage" >
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <div class="row mobileScreenMessage">
      <div class="col">
          <p class="lead text-center mt-3">
            It seems you are browsing with your mobile phone. If you want to get cms functionality then visit
            laptop or desktop screen size
        </p>
      </div>
    </div>
      <div class="row d-sm-flex d-none">
       
            <div class="col-md-3">
               <div class="card">
                 <div class="card-header">Menu</div>
                  <div class="list-group">
                <a href="<?php echo e(route('welcome.home')); ?>" 
                class="list-group-item list-group-item-action <?php echo e(Request::path() == '/' ? 'active' : ''); ?>">Home</a>
                <a href="<?php echo e(route('posts.index')); ?>" 
                class="list-group-item list-group-item-action <?php echo e(Request::path() == 'posts' ? 'active' : ''); ?>">My Posts</a>
                <a href="<?php echo e(route('categories.index')); ?>"
                 class="list-group-item list-group-item-action <?php echo e(Request::path() == 'categories' ? 'active' : ''); ?>">Categories</a>
                <a href="<?php echo e(route('tags.index')); ?>" 
                class="list-group-item list-group-item-action <?php echo e(Request::path() == 'tags' ? 'active' : ''); ?>">Tags</a>
                <a href="<?php echo e(route('dashboard')); ?>"
                 class="list-group-item list-group-item-action <?php echo e(Request::path() == 'dashboard' ? 'active' : ''); ?>">Dashbaord</a>
                <a href="<?php echo e(route('posts.create')); ?>"
                 class="list-group-item list-group-item-action <?php echo e(Request::path() == 'posts/create' ? 'active' : ''); ?>">Create Post</a>
                <a href="<?php echo e(route('categories.create')); ?>"
                 class="list-group-item list-group-item-action <?php echo e(Request::path() == 'categories/create' ? 'active' : ''); ?>">Create Category</a>
                <a href="<?php echo e(route('tags.create')); ?>"
                 class="list-group-item list-group-item-action <?php echo e(Request::path() == 'tags/create' ? 'active' : ''); ?>">Create Tag</a>
                <a href="<?php echo e(route('trashed-posts.index')); ?>" 
               class="list-group-item list-group-item-action <?php echo e(Request::path() == 'trashed-posts' ? 'active' : ''); ?>">Trashed</a>
                <?php if(auth()->user()->role == "admin"): ?>
                   <a href="<?php echo e(route('users.index')); ?>" 
                   class="list-group-item list-group-item-action <?php echo e(Request::path() == 'users' ? 'active' : ''); ?>">Users</a>
                <?php endif; ?>
                  
            </div> 
          </div>
     </div> 

    <div class="col-md-9">
               <?php echo $__env->yieldContent('content'); ?>
    </div>
   </div>
 </div>
  <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>


   <?php echo $__env->yieldContent('script'); ?>
    <script>
        setTimeout(function() {
        $('.successMessage').fadeOut('slow');
        }, 3000);
        setTimeout(function() {
        $('.errorMessage').fadeOut('slow');
        }, 3000);

           if ($(window).width() < 560) {
                $( document ).ready(function() {
                 $(".mobileScreenMessage").show();
               });
            } else {
                 $('.mobileScreenMessage').hide();
               
            }
    </script>
  </body>
</html>
<?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/layouts/main.blade.php ENDPATH**/ ?>