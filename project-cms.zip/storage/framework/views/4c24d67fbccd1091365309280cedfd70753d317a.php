   <?php $__env->startSection('content'); ?>

   

    <div class="d-flex flex-column align-items-center mb-5">
    <div class="align-self-end">
        <a href=" <?php echo e(route('categories.create')); ?> " class="btn btn-primary mb-3"> Create Category</a>
    </div>

    <div class="card" style="width: 100%">
          <div class="card-header">
            Categories
          </div>
         <?php if($categories->count() > 0): ?>
            <ul class="list-group list-group-flush  p-3">
             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="list-group">
               <div class="d-flex justify-content-between align-items-center mb-3">
                    <a href="#" class="list-group-item list-group-item-action"><div class="d-flex justify-content-between">
                     <span><?php echo e(substr($category->name, 0,20)); ?></span>  <span>Posts: <?php echo e($category->posts->count()); ?></span>
                    </div>
                    </a>
                    <a href="<?php echo e(route('categories.edit' , $category->id)); ?>" class="btn btn-info ml-2 mr-2">Edit</a>
                    <button type="button" class="btn btn-danger" onclick="handleDelete(<?php echo e($category->id); ?>)">
                    Delete
                    </button>
                </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Button trigger modal -->
         </ul>
        <!-- Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
           <form action="" method="POST" id="deleteCategoryForm">
               <?php echo method_field('DELETE'); ?>
               <?php echo csrf_field(); ?>
             <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Delete Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               Are you sure you want to delete  category ?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, Go Back</button>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
            </div>
            </div>
           </form>
        </div>
        </div>
        </div>

          <div class="mt-3">
              <?php echo e($categories->links('pagination::simple-tailwind')); ?>

           </div>
         <?php else: ?>
             <h2 class="p-2 text-center">No Category Yet</h2>
         <?php endif; ?>
   </div>
   </div>
   <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

    <script>
        function handleDelete(id){

            var from = document.getElementById('deleteCategoryForm');
            from.action = '/categories/' + id;
            $('#deleteModal').modal('show')
        }

    </script>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/categories/index.blade.php ENDPATH**/ ?>