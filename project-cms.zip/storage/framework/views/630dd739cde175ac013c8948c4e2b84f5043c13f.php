<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <title>
      <?php echo $__env->yieldContent('title'); ?>
    </title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/page.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('img/apple-touch-icon.png')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>">
  </head>
  <body>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-stick-dark" data-navbar="sticky">
      <div class="container">

        <div class="navbar-left">
          <button class="navbar-toggler" type="button"> &#9776; </button>
             <a class="navbar-brand" href="/">
              <img class="logo-dark" src="<?php echo e(asset('img/logo-dark.png')); ?>" alt="logo">
              <img class="logo-light" src="<?php echo e(asset('img/logo-light.png')); ?>" alt="logo">
             </a> 
        </div>
      <div>


     <?php if(auth()->user()): ?>
        <section class="navbar-mobile">
         <span class="navbar-divider d-mobile-none"></span>
          <ul class="nav nav-navbar">           
            <li class="nav-item">
             <a class="nav-link" href="#"><?php echo e(auth()->user()->name); ?><span class="arrow"></span></a>
              <nav class="nav">
                <a class="nav-link" href="<?php echo e(route('profile.show')); ?>">My Profile</a>
                <a class="nav-link" href="<?php echo e(route('posts.create')); ?>">Create Post</a>
                <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">My Posts</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-2">
                  <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                        this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                        this.closest(\'form\').submit();']); ?>
                  <div class="btn btn-xs btn-round btn-secondary"><?php echo e(__('Log Out')); ?></div>
               <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
              </form>  
              </nav>
                
            </li>
        </ul>
        </section>
           <?php else: ?>

      <section class="navbar-mobile">
         <span class="navbar-divider d-mobile-none"></span>
          <ul class="nav nav-navbar">           
            <li class="nav-item">
             <a class="nav-link" href="#">Menu<span class="arrow"></span></a>
              <nav class="nav">
                <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
              </nav>
                
            </li>
        </ul>
        </section>


           
           <?php endif; ?>
        </div>
      </div>
    </nav>
    <!-- /.navbar -->


    <?php echo $__env->yieldContent('header'); ?>


    <!-- Main Content -->
    <?php echo $__env->yieldContent('content'); ?>
               



    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <div class="row gap-y align-items-center">

          <div class="col-4 col-lg-6">
            <a href="../index.html"><img src="<?php echo e(asset('img/logo-dark.png')); ?>" alt="logo"></a>
          </div>

          <div class="col-8 col-lg-6 text-right order-lg-last">
            <div class="social">
              <a class="social-facebook "   href="https://www.facebook.com"><i class="fa fa-facebook"></i></a>
              <a class="social-twitter  "   href="https://twitter.com"><i class="fa fa-twitter"></i></a>
              <a class="social-instagram"   href="https://www.instagram.com"><i class="fa fa-instagram"></i></a>
              <a class="social-dribbble "   href="https://dribbble.com"><i class="fa fa-dribbble"></i></a>
            </div>
          </div>


        </div>
      </div>
    </footer><!-- /.footer -->


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/page.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>

  </body>
</html>


<?php /**PATH D:\courses\Debsish  Webstie template\Laravel\project-cms\resources\views/layouts/blog.blade.php ENDPATH**/ ?>